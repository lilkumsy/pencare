USE [PFA]
GO

/****** Object:  Table [dbo].[pencare_consent]    Script Date: 05/02/2026 09:08:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[pencare_consent](
	[ConsentID] [int] IDENTITY(1,1) NOT NULL,
	[PIN] [varchar](20) NOT NULL,
	[FirstName] [varchar](100) NULL,
	[Surname] [varchar](100) NULL,
	[OtherNames] [varchar](100) NULL,
	[DateOfBirth] [date] NULL,
	[StateOfPosting] [varchar](100) NULL,
	[ConsentGiven] [bit] NOT NULL,
	[ConsentDate] [datetime] NULL,
	[IPAddress] [varchar](50) NULL,
	[UserAgent] [varchar](255) NULL,
	[Gender] [varchar](20) NULL,
	[Email] [varchar](150) NULL,
	[MobileNumber] [varchar](50) NULL,
	[NIN] [varchar](50) NULL,
	[Address] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[ConsentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[pencare_consent] ADD  DEFAULT (getdate()) FOR [ConsentDate]
GO


