<?php
// includes/db.php

$server = "192.168.10.26";
$database = "PFA";
$username = "sa";
$password = "Viewp@55";

try {
    // Add TrustServerCertificate=true to bypass SSL certificate validation for local servers
    $conn = new PDO(
        "sqlsrv:Server=$server;Database=$database;TrustServerCertificate=true",
        $username,
        $password
    );
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Set default fetch mode to associative array
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // DISPLAY the error directly so we can debug it
    die("<h3>Database Connection Failed</h3><hr><strong>Error Detail:</strong> " . $e->getMessage() . "<br><br>Please check your credentials in <code>includes/db.php</code>.");
}
?>